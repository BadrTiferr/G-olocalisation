function supports_geolocation() {
  return !!navigator.geolocation;
}

function get_location() {
  if ( supports_geolocation() ) {
    navigator.geolocation.getCurrentPosition(show_map, handle_error);
  } else {
  $("#msg").text('Votre Navigateur ne supporte pas la géolocalisation');
  $("#collection").text('©2018 TIFERRAS Badr');
  }
}

function show_map(position) {
  var latitude = position.coords.latitude;
  var longitude = position.coords.longitude;
  
  $("#geo-wrapper").css({'width':'600px','height':'480px'});
  
  var latlng = new google.maps.LatLng(latitude, longitude);
  var myOptions = {
    zoom: 15,
    center: latlng,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  var map = new google.maps.Map(document.getElementById("geo-wrapper"), myOptions);
  
  var marker = new google.maps.Marker({
    position: latlng,
    title:"Vous êtes plus ou moin ici"
  });
  
  marker.setMap(map);
  
  $("#msg").text('Vous êtes ici:');
  $("#lat").text('Latitude: ' + latitude);
  $("#long").text('Longitude: ' + longitude);
  $("#collection").text('©2018 TIFERRAS Badr');
}

function handle_error(err) {
  if (err.code == 1) {
  $("#msg").text('Vous avez choisi de ne pas partager votre postion.');
  $("#collection").text('©2018 TIFERRAS Badr');
  }
}

get_location();